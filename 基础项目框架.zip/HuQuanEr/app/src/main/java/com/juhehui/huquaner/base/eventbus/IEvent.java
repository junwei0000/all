package com.juhehui.huquaner.base.eventbus;

/**
 * Created by liuchao on 2018.5.28.
 */
public abstract class IEvent {

    EventCenter event = null;
    boolean isSticky = false;

    protected void setSticky(boolean isSticky) {
        this.isSticky = isSticky;
    }
}
