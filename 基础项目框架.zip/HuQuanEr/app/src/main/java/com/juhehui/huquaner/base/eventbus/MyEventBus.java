package com.juhehui.huquaner.base.eventbus;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;

import org.greenrobot.eventbus.EventBus;

import java.util.ArrayList;

/**
 * Created by liuchao on 2018.5.28.
 */
public class MyEventBus {
    static volatile MyEventBus defaultInstance;
    static EventBusSubscribe eventBusSubscribe = null;
    private ArrayList<IEvent> mStickyList = new ArrayList<>();
    public static final int WHAT_POSTSTICK = 1;

    private Handler mHandler = new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case WHAT_POSTSTICK:
                    postSticky();
                    break;
            }
        }
    };

    private void postSticky() {
        if (mStickyList.size() > 0) {
            ArrayList<IEvent> list = (ArrayList<IEvent>) mStickyList.clone();
            mStickyList.clear();
            for (IEvent event : list) {
                EventBus.getDefault().post(event);
            }
        }
    }


    public static MyEventBus getDefault() {
        if (defaultInstance == null) {
            synchronized (MyEventBus.class) {
                if (defaultInstance == null) {
                    defaultInstance = new MyEventBus();
                    eventBusSubscribe = new EventBusSubscribe();
                }
            }
        }
        return defaultInstance;
    }

    public void register(Object subscriber) {
        if (eventBusSubscribe.isEmpty()) {
            EventBus.getDefault().register(eventBusSubscribe);
        }
        eventBusSubscribe.register(subscriber);
        mHandler.removeMessages(WHAT_POSTSTICK);
        mHandler.sendEmptyMessageDelayed(WHAT_POSTSTICK, 0);
    }

    public boolean isRegistered(Object subscriber) {
        return eventBusSubscribe.isRegistered(subscriber);
    }

    public void unregister(Object subscriber) {
        eventBusSubscribe.unregister(subscriber);
        if (eventBusSubscribe.isEmpty()) {
            EventBus.getDefault().unregister(eventBusSubscribe);
            mStickyList.clear();
        } else {
            mHandler.removeMessages(WHAT_POSTSTICK);
            mHandler.sendEmptyMessageDelayed(WHAT_POSTSTICK, 500);
        }
    }

    public static void destroy() {
        defaultInstance = null;
    }


    public void postCurrent(EventCenter event) {
        EventBus.getDefault().post(new CurrentEvent(event));
    }

    public void postMain(EventCenter event) {
        EventBus.getDefault().post(new MainEvent(event));
    }

    public void postBack(EventCenter event) {
        EventBus.getDefault().post(new BackEvent(event));
    }

    public void postAsync(EventCenter event) {
        EventBus.getDefault().post(new AsyncEvent(event));
    }

    /**
     * 关于sticky事件参考eventbus 用法
     *
     * @param event
     */
    public void postCurrentSticky(EventCenter event) {
        CurrentEvent event1 = new CurrentEvent(event);
        event1.setSticky(true);
        mStickyList.add(event1);
    }

    public void postMainSticky(EventCenter event) {
        MainEvent event1 = new MainEvent(event);
        event1.setSticky(true);
        mStickyList.add(event1);
    }

    public void postBackSticky(EventCenter event) {
        BackEvent event1 = new BackEvent(event);
        event1.setSticky(true);
        mStickyList.add(event1);
    }

    public void postAsyncSticky(EventCenter event) {
        AsyncEvent event1 = new AsyncEvent(event);
        event1.setSticky(true);
        mStickyList.add(event1);
    }

    public void removeAllSticky() {
        mStickyList.clear();
    }
//    public void cancelEventDelivery(Object event) {
//        EventBus.getDefault().cancelEventDelivery(event);
//    }
//
//    public void postSticky(Object event) {
//        EventBus.getDefault().postSticky(event);
//    }
}
