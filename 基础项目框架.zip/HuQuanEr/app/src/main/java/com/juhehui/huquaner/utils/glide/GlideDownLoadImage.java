package com.juhehui.huquaner.utils.glide;

import android.content.Context;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.Priority;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.drawable.GlideDrawable;
import com.bumptech.glide.request.animation.GlideAnimation;
import com.bumptech.glide.request.target.SimpleTarget;
import com.juhehui.huquaner.R;
import com.juhehui.huquaner.base.HQApplication;

/**
 * 作者：MarkMingShuai
 * 时间 2017-8-9 11:13
 * 邮箱：mark_mingshuai@163.com
 * <p>
 * 类的意图：Glide加载图片工具类
 */
public class GlideDownLoadImage {

    private static final String TAG = "ImageLoader";

    private static GlideDownLoadImage instance = new GlideDownLoadImage();

    public static GlideDownLoadImage getInstance() {
        return instance;
    }


    /**
     * @param
     * @name 加载本地图片的重载方法 此方法慎用
     * @auhtor MarkMingShuai
     * @Data 2017-9-5 11:10
     */
    public void loadImage(int resId, ImageView view) {
        Glide.with(HQApplication.getContext())
                .load(resId)
                .error(R.mipmap.moren_new)
                .diskCacheStrategy(DiskCacheStrategy.SOURCE)
                .into(view);
    }


    /**
     * @param mContext
     * @param resId
     * @param view
     * @name 加载本地圆图
     * @auhtor MarkMingShuai
     * @Data 2017-9-5 11:18
     */
    public void loadCircleImage(Context mContext, int resId, ImageView view) {
        Glide.with(HQApplication.getContext())
                .load(resId)
                .placeholder(R.mipmap.user_default_icon)
                .error(R.mipmap.user_default_icon)
                .bitmapTransform(new GlideCircleTransform(HQApplication.getContext()))
                .diskCacheStrategy(DiskCacheStrategy.SOURCE)
                .into(view);
    }


    /**
     * 加载 网络头像,SimpleTarget防止无法显示需要刷新问题
     *
     * @param url
     * @param view
     * @auhtor MarkMingShuai
     * @Data 2017-9-5 11:18
     */
    public void loadCircleHeadImageCenter(Context mContext, String url, final ImageView view) {
        Glide.with(HQApplication.getContext())
                .load(url)
                .placeholder(R.mipmap.user_default_icon)
                .error(R.mipmap.user_default_icon)
                .priority(Priority.HIGH)
                .bitmapTransform(new GlideCircleTransform(HQApplication.getContext()))
                .diskCacheStrategy(DiskCacheStrategy.SOURCE)
                .into(new SimpleTarget<GlideDrawable>() {
                    @Override
                    public void onResourceReady(GlideDrawable resource, GlideAnimation<? super GlideDrawable> glideAnimation) {
                        //图片加载完成
                        if (view != null)
                            view.setImageDrawable(resource);
                    }
                });
    }

    /**
     * @param url
     * @param view
     * @name 加载网络圆图
     * @auhtor MarkMingShuai
     * @Data 2017-9-5 11:18
     */
    public void loadCircleImage(String url, ImageView view) {
        Glide.with(HQApplication.getContext())
                .load(url)
                .placeholder(R.mipmap.user_default_icon)
                .error(R.mipmap.user_default_icon)
                .bitmapTransform(new GlideCircleTransform(HQApplication.getContext()))
                .diskCacheStrategy(DiskCacheStrategy.SOURCE)
                .into(view);
    }


    /**
     * @param mContext
     * @param url
     * @param view
     * @name 加载网络圆图
     * @auhtor MarkMingShuai
     * @Data 2017-9-5 11:18
     */
    public void loadCircleImageCommune(Context mContext, String url, ImageView view) {
        Glide.with(HQApplication.getContext())
                .load(url)
                .placeholder(R.mipmap.icon_commune_round)
                .error(R.mipmap.icon_commune_round)
                .bitmapTransform(new GlideCircleTransform(HQApplication.getContext()))
                .diskCacheStrategy(DiskCacheStrategy.SOURCE)
                .into(view);
    }

    /**
     * @param mContext
     * @param url
     * @param view
     * @param dp
     * @name 加载网络带角度的图片
     * @auhtor MarkMingShuai
     * @Data 2017-9-5 11:18
     */
    public void loadCircleImageCommune(Context mContext, String url, ImageView view, int dp) {
        Glide.with(HQApplication.getContext())
                .load(url)
                .placeholder(R.mipmap.icon_commune)
                .error(R.mipmap.icon_commune)
                .bitmapTransform(new GlideRoundTransform(HQApplication.getContext(), dp))
                .diskCacheStrategy(DiskCacheStrategy.SOURCE)
                .into(view);
    }

    /**
     * 防止加载图片背景闪动
     *
     * @param url
     * @param view
     * @param dp
     * @name 加载网络带角度的图片
     * @auhtor MarkMingShuai
     * @Data 2017-9-5 11:18
     */
    public void loadCircleImageLive(String url, int mipmapid, ImageView view, int dp) {
        GlideRoundTransform mGlideRoundTransform = new GlideRoundTransform(HQApplication.getContext(), dp);
//        mGlideRoundTransform.setExceptCorner(false, false, true, true);
        Glide.with(HQApplication.getContext())
                .load(url)
                .error(mipmapid)
                .transform(mGlideRoundTransform)
                .diskCacheStrategy(DiskCacheStrategy.SOURCE)
                .into(view);
    }


    /**
     * @param resId
     * @param view
     * @param dp
     * @name 加载本地带角度的图片
     * @auhtor MarkMingShuai
     * @Data 2017-9-5 11:18
     */
    public void loadCircleImageRole(int resId, ImageView view, int dp) {
        Glide.with(HQApplication.getContext())
                .load(resId)
                .placeholder(R.mipmap.moren_new)
                .error(R.mipmap.moren_new)
                .bitmapTransform(new GlideRoundTransform(HQApplication.getContext(), dp))
                .diskCacheStrategy(DiskCacheStrategy.SOURCE)
                .into(view);
    }

    /**
     * @param mContext
     * @param url
     * @param view
     * @param dp
     * @name 加载网络带角度的图片
     * @auhtor MarkMingShuai
     * @Data 2017-9-5 11:18
     */
    public void loadCircleImageRole(Context mContext, String url, ImageView view, int dp) {
        Glide.with(HQApplication.getContext())
                .load(url)
                .placeholder(R.mipmap.moren_new)
                .error(R.mipmap.moren_new)
                .bitmapTransform(new GlideRoundTransform(HQApplication.getContext(), dp))
                .diskCacheStrategy(DiskCacheStrategy.SOURCE)
                .into(view);
    }

    /**
     * 加载方形默认背景图片
     *
     * @param mContext
     * @param url
     * @param view
     * @param dp
     */
    public void loadCircleImageRoleSquare(Context mContext, String url, ImageView view, int dp) {
        Glide.with(HQApplication.getContext())
                .load(url)
                .placeholder(R.mipmap.moren_new_square)
                .error(R.mipmap.moren_new_square)
                .bitmapTransform(new GlideRoundTransform(HQApplication.getContext(), dp))
                .diskCacheStrategy(DiskCacheStrategy.SOURCE)
                .into(view);
    }

    public void loadCircleImageRoleGoods(Context mContext, String url, ImageView view, int dp) {
        Glide.with(HQApplication.getContext())
                .load(url)
                .placeholder(R.mipmap.mall_icon_thedefault)
                .error(R.mipmap.mall_icon_thedefault)
                .bitmapTransform(new GlideRoundTransform(HQApplication.getContext(), dp))
                .diskCacheStrategy(DiskCacheStrategy.SOURCE)
                .into(view);
    }

    public void loadCircleImageRoleGoodsDetail(Context mContext, String url, ImageView view, int dp) {
        Glide.with(HQApplication.getContext())
                .load(url)
                .placeholder(R.mipmap.mall_icon_thedefault2)
                .error(R.mipmap.mall_icon_thedefault2)
                .bitmapTransform(new GlideRoundTransform(HQApplication.getContext(), dp))
                .diskCacheStrategy(DiskCacheStrategy.SOURCE)
                .into(view);
    }

    /**
     * @param mContext
     * @param url
     * @param view
     * @param dp
     * @name 加载网络带角度的图片
     * @auhtor MarkMingShuai
     * @Data 2017-9-5 11:18
     */
    public void loadCircleImageRoleREf(Context mContext, String url, final ImageView view, int dp) {
        Glide.with(HQApplication.getContext())
                .load(url)
                .placeholder(R.mipmap.moren_new)
                .error(R.mipmap.moren_new)
                .bitmapTransform(new GlideRoundTransform(HQApplication.getContext(), dp))
                .diskCacheStrategy(DiskCacheStrategy.SOURCE)
                .into(new SimpleTarget<GlideDrawable>() {
                    @Override
                    public void onResourceReady(GlideDrawable resource, GlideAnimation<? super GlideDrawable> glideAnimation) {
                        //图片加载完成
                        if (view != null)
                            view.setImageDrawable(resource);
                    }
                });
    }

    /**
     * @param url
     * @param view
     * @name 加载网络带角度的图片
     * @auhtor MarkMingShuai
     * @Data 2017-9-5 11:18
     */
    public void loadCircleImageRoleREf2(String url, ImageView view, int dp) {
        Glide.with(HQApplication.getContext())
                .load(url).asBitmap()
                .placeholder(R.mipmap.moren_new)
                .error(R.mipmap.moren_new)
                .diskCacheStrategy(DiskCacheStrategy.SOURCE)
                .into(view);
    }
}
