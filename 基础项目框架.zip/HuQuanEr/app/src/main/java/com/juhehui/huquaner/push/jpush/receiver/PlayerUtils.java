package com.juhehui.huquaner.push.jpush.receiver;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;


import com.juhehui.huquaner.R;

import java.util.HashMap;

/**
 * Created by Burning on 2018/9/5.
 */

public class PlayerUtils {


    MediaPlayer mcsdPlayer;
    MediaPlayer mphPlayer;

    long csdTime;
    long phTime;
    private static volatile PlayerUtils INSTANCE;

    public static PlayerUtils getINSTANCE() {
        if (INSTANCE == null) {
            synchronized (PlayerUtils.class) {
                if (INSTANCE == null) {
                    INSTANCE = new PlayerUtils();
                }
            }
        }
        return INSTANCE;
    }

    /**
     * 财神到音乐
     *
     * @param context
     */
    public void playCSD(Context context) {
        if (mcsdPlayer == null) {
            mcsdPlayer = MediaPlayer.create(context, R.raw.caishendao);
        }
        if (mcsdPlayer != null && !mcsdPlayer.isPlaying() && (System.currentTimeMillis() / 1000 - csdTime > 60 * 10)) {
            mcsdPlayer.start();
            csdTime = System.currentTimeMillis() / 1000;
        }
    }

    /**
     * 福祺宝祝佑宝 平衡 提示
     *
     * @param context
     */
    public void playPingHeng(Context context) {
        if (mphPlayer == null) {
            mphPlayer = MediaPlayer.create(context, R.raw.pingheng);
        }
        if (mphPlayer != null && !mphPlayer.isPlaying() && (System.currentTimeMillis() / 1000 - phTime > 60 * 10)) {
            mphPlayer.start();
            phTime = System.currentTimeMillis() / 1000;
        }
    }




    /**
     * 播放本地视频 "/storage/emulated/0/joke_essay/1486844342617.mp4"
     */
    public static void playNativeVideo(Activity mActivity, String videoPath) {

        Intent intent = new Intent(Intent.ACTION_VIEW);
        String type = "video/mp4";
        Uri uri = Uri.parse(videoPath);
        intent.setDataAndType(uri, type);
        mActivity.startActivity(intent);
    }

    /**
     * 播放网络视频
     */
    public static void playNetworkVideo(Activity mActivity, String videoPath) {

        Intent intent = new Intent(Intent.ACTION_VIEW);
        String type = "video/*";

        Uri uri = Uri.parse(videoPath);
        intent.setDataAndType(uri, type);
        mActivity.startActivity(intent);
    }

    /**
     * 这样会默认用浏览器打开这个URL！
     */
    public void playNetworkVideoDefault(Activity mActivity, String videoPath) {

        Intent intent = new Intent(Intent.ACTION_VIEW);

        Uri uri = Uri.parse(videoPath);
        intent.setData(uri);
        mActivity.startActivity(intent);
    }

    /**
     * 获取视频时长
     *
     * @param videoPath
     * @return
     */
    public String getDuration(String videoPath) {
        MediaMetadataRetriever mmr = new MediaMetadataRetriever();
        mmr.setDataSource(videoPath);
        String duration = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION); // 播放时长单位为毫秒
        return duration;
    }


    /**
     * 获取视频缩略图
     *
     * @return
     */
    @TargetApi(Build.VERSION_CODES.ICE_CREAM_SANDWICH)
    public Bitmap createVideoThumbnail(String url, int width, int height) {
        Bitmap bitmap = null;
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        int kind = MediaStore.Video.Thumbnails.MINI_KIND;
        try {
            if (Build.VERSION.SDK_INT >= 14) {
                retriever.setDataSource(url, new HashMap<String, String>());
            } else {
                retriever.setDataSource(url);
            }
            bitmap = retriever.getFrameAtTime();
        } catch (IllegalArgumentException ex) {
            // Assume this is a corrupt video file
        } catch (RuntimeException ex) {
            // Assume this is a corrupt video file.
        } finally {
            try {
                retriever.release();
            } catch (RuntimeException ex) {
                // Ignore failures while cleaning up.
            }
        }
        if (kind == MediaStore.Images.Thumbnails.MICRO_KIND && bitmap != null) {
            bitmap = ThumbnailUtils.extractThumbnail(bitmap, width, height,
                    ThumbnailUtils.OPTIONS_RECYCLE_INPUT);
        }
        return bitmap;
    }

}
