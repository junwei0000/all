package com.juhehui.huquaner.utils.widget.jswebview.browse;


/**
 * @param
 * @author MarkShuai
 * @name
 */
public interface BridgeHandler {

    void handler(String data, CallBackFunction function);

}
