package com.juhehui.huquaner.modular;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.juhehui.huquaner.R;
import com.juhehui.huquaner.base.ActivityManager;
import com.juhehui.huquaner.base.BaseActivity;
import com.juhehui.huquaner.push.jpush.broadcast.LocalBroadcastManager;
import com.juhehui.huquaner.utils.ConstantManager;
import com.juhehui.huquaner.utils.PriceUtils;
import com.juhehui.huquaner.utils.myview.MyViewPager;
import com.juhehui.huquaner.utils.sharedpreferenceutils.SharedPreferencesHelper;
import com.juhehui.huquaner.utils.widget.Immersive;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;

public class BottomMenuActivity extends BaseActivity {

    @BindView(R.id.vp_bt_menu)
    MyViewPager mViewPager;

    @BindView(R.id.bottom_iv_home)
    ImageView bottomIvHome;
    @BindView(R.id.bottom_tv_home)
    TextView bottomTvHome;
    @BindView(R.id.bottom_iv_helpWith)
    ImageView bottomIvHelpWith;
    @BindView(R.id.bottom_tv_helpWith)
    TextView bottomTvHelpWith;
    @BindView(R.id.bottom_tv_me)
    TextView bottomTvMe;
    @BindView(R.id.bottom_iv_me)
    ImageView bottomIvMe;
    @BindView(R.id.bottom_layout_home)
    LinearLayout bottomLayoutHome;
    @BindView(R.id.bottom_layout_helpWith)
    LinearLayout bottomLayoutHelpWith;
    @BindView(R.id.bottom_layout_me)
    LinearLayout bottomLayoutMe;


    public static List<Fragment> fragmentList = new ArrayList<>();
    private MessageReceiver mMessageReceiver;
    public static int position;

    /**
     * 点击收藏登录记录之前的tab
     */
    private int before_tab_position;
    /**
     * 点击之后正常要跳转的
     */
    private int after_tab_position;

    public static final int tab_position_home = 0;
    public static final int tab_position_help = 1;
    public static final int tab_position_mine = 2;

    public static Activity mMenuContext;

    @Override
    public View bindView() {
        return null;
    }

    @Override
    public int bindLayout() {
        return R.layout.activity_bottom_menu;
    }


    @Override
    public void initView(View view) {
        mMenuContext = this;
        registerMessageReceiver();
        Immersive.setStatusBarFragment(mActivity);
    }


    @Override
    public void initDataAfter() {
        initFragment();
        setPageAdapter();
        // 默认选中首页
        before_tab_position = tab_position_home;
        selectPage(tab_position_home);
    }


    @Override
    public void setListener() {
        bottomLayoutHome.setOnClickListener(this);
        bottomLayoutHelpWith.setOnClickListener(this);
        bottomLayoutMe.setOnClickListener(this);
    }


    /**
     * 是否登录判断
     */

    private void chackSkipByLoginStatus() {
        try {
            String loginStatus = (String) SharedPreferencesHelper.get(getApplicationContext(), "loginStatus", "");
            if (loginStatus.equals(ConstantManager.loginStatus)) {
                selectPage(after_tab_position);
            } else {
                SharedPreferencesHelper.put(mActivity, "loginSkipToStatus", ConstantManager.loginSkipToMainNext);
//                Intent intent = new Intent(mContext, LoginActivity.class);
//                intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
//                startActivity(intent);
//                ConfigUtils.getINSTANCE().setPageIntentAnim(intent, mActivity);
            }
        } catch (Exception e) {
        }

    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            //主页
            case R.id.bottom_layout_home:
                selectPage(tab_position_home);
                break;
            //互助
            case R.id.bottom_layout_helpWith:
                after_tab_position = tab_position_help;
                chackSkipByLoginStatus();
                break;
            //我的
            case R.id.bottom_layout_me:
                after_tab_position = tab_position_mine;
                chackSkipByLoginStatus();
                break;
        }
    }


    private void setBottomBtn() {

        bottomTvHome.setTextColor(getResources().getColor(R.color.main_tab_text_color));
        bottomTvHelpWith.setTextColor(getResources().getColor(R.color.main_tab_text_color));
        bottomTvMe.setTextColor(getResources().getColor(R.color.main_tab_text_color));
        bottomIvHome.setColorFilter(getResources().getColor(R.color.gray_bian));
        bottomIvHelpWith.setColorFilter(getResources().getColor(R.color.gray_bian));
        bottomIvMe.setColorFilter(getResources().getColor(R.color.gray_bian));
        if (position == tab_position_home) {
            bottomTvHome.setTextColor(getResources().getColor(R.color.blue_new));
        } else if (position == tab_position_help) {
            bottomTvHelpWith.setTextColor(getResources().getColor(R.color.blue_new));
        } else if (position == tab_position_mine) {
            bottomTvMe.setTextColor(getResources().getColor(R.color.blue_new));
        }
    }


    /**
     * @param
     * @name 初始化Fragment
     * @time 2017/11/24 10:23
     * @author MarkShuai
     */
    private void initFragment() {

    }

    /**
     * @param
     * @name 设置PagerAdapter
     * @time 2017/11/24 10:44
     * @author MarkShuai
     */
    private void setPageAdapter() {
        TabPageAdapter tabPageAdapter = new TabPageAdapter(getSupportFragmentManager(), fragmentList);
        mViewPager.setAdapter(tabPageAdapter);
        mViewPager.setOffscreenPageLimit(4);
        /**
         * 设置是否可以滑动
         */
        mViewPager.setScroll(false);
    }

    /**
     * 选择某页
     *
     * @param position 页面的位置
     */
    private void selectPage(int position) {
        BottomMenuActivity.position = position;
        // 切换页面
        mViewPager.setCurrentItem(position, false);
        setBottomBtn();
    }

    /**
     * 是否显示版本更新提示/通知弹层
     */
    public static boolean updatedialogstatus = false;

    /**
     * 弹出版本更新时，关闭两个页面的弹层
     */
    private void UpdatVerDisAllDialog() {
        updatedialogstatus = true;
        DisAllDialog();
    }

    private void DisAllDialog() {
    }


    public void registerMessageReceiver() {
        mMessageReceiver = new MessageReceiver();
        IntentFilter filter = new IntentFilter();
        filter.setPriority(IntentFilter.SYSTEM_HIGH_PRIORITY);
        filter.addAction(ConstantManager.MAINMENU_ACTION);
        LocalBroadcastManager.getInstance(this).registerReceiver(mMessageReceiver, filter);
    }


    public class MessageReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            try {
                Bundle bundle = intent.getExtras();
                if (bundle != null) {
                    String type = bundle.getString("type", "");
                    if (type.equals(ConstantManager.MAIN_ACTION_TYPE_HOME)) {
                        selectPage(tab_position_home);
                    } else if (type.equals(ConstantManager.MAIN_ACTION_TYPE_CENTER)) {
                        selectPage(tab_position_mine);
                    } else if (type.equals(ConstantManager.MAIN_ACTION_TYPE_BACK)) {
                        selectPage(before_tab_position);
                    } else if (type.equals(ConstantManager.MAIN_ACTION_TYPE_NEXT)) {
                        selectPage(after_tab_position);
                    } else if (type.equals(ConstantManager.MAIN_ACTION_UpdateVerDisAllDialog)) {
                        UpdatVerDisAllDialog();
                    } else if (type.equals(ConstantManager.MAIN_ACTION_UpdateVerDisAllDialog)) {
                        UpdatVerDisAllDialog();
                    }
                }
            } catch (Exception e) {
            }
        }
    }

    @Override
    protected void onStop() {
        DisAllDialog();
        super.onStop();
    }


    @Override
    protected void onDestroy() {
        DisAllDialog();
        LocalBroadcastManager.getInstance(this).unregisterReceiver(mMessageReceiver);
        super.onDestroy();
    }

    /**
     * 监听返回键
     */
    public void onBackPressed() {
        if (position != tab_position_home) {
            selectPage(tab_position_home);
        } else {
//            exit();
            PriceUtils.getInstance().mbackgroundStatus = true;
            ActivityManager.getScreenManager().backHome(mActivity);
        }
    }

}
