package com.juhehui.huquaner.base.eventbus;

/**
 * Created by liuchao on 2018.5.28.
 */
public interface IEventBusListener {
    //事件自上向下分发（越早注册的事件越靠下） 如果返回true事件会终止下发
    boolean onInterceptEvent(EventCenter msg);

    boolean onInterceptEventMainThread(EventCenter msg);

    boolean onInterceptEventBackgroundThread(EventCenter msg);

    boolean onInterceptEventAsync(EventCenter msg);

}
