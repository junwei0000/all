package com.juhehui.huquaner.utils.pay;

/**
 * @author MarkShuai
 * @name 定制支付枚举
 * @time 2017/12/5 15:46
 */
public enum PayEnum {
    ALIPAY, WECHAT, NO
}
