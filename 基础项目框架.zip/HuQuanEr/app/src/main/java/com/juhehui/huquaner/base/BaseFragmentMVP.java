package com.juhehui.huquaner.base;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.juhehui.huquaner.base.eventbus.EventCenter;
import com.juhehui.huquaner.base.eventbus.IEventBusListener;
import com.juhehui.huquaner.base.eventbus.MyEventBus;
import com.trello.rxlifecycle2.components.support.RxFragment;

import butterknife.ButterKnife;
import butterknife.Unbinder;

/**
 * 作者：MarkMingShuai
 * 时间 2017-8-9 14:19
 * 邮箱：mark_mingshuai@163.com
 * 类的意图：Fragment 的基础类
 */

public abstract class BaseFragmentMVP<V, T extends BasePresent<V>> extends RxFragment implements View.OnClickListener, IEventBusListener {

    /**
     * P层引用
     */
    protected T mPresent;

    protected final String TAG = this.getClass().getSimpleName();
    private View mContextView = null;
    protected Context mContext = null;
    protected Activity mActivity = null;
    //
    private Unbinder unbinder;


    private boolean isResiterEvent = false;

    /**
     * 懒加载
     */
    //Fragment的View加载完毕的标记
    private boolean isViewCreated;
    //Fragment对用户可见的标记
    private boolean isUIVisible;

    private boolean isVisibleLoad = false;

    public boolean isVisibleLoad() {
        return isVisibleLoad;
    }

    public void setVisibleLoad(boolean visibleLoad) {
        isVisibleLoad = visibleLoad;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = getContext();
        mActivity = getActivity();
        //创建Presenter层
        mPresent = createPresent();
        //做绑定
        mPresent.attachView((V) this);

    }

    /**
     * 解决java.lang.IllegalStateException: Bindings already cleared.
     *
     * @param inflater
     * @param container
     * @param savedInstanceState
     * @return
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (mContextView != null) {
            ViewGroup parent = (ViewGroup) mContextView.getParent();
            if (parent != null) {
                parent.removeView(mContextView);
            }
        } else {
            mContextView = inflater.inflate(bindLayout(), container, false);
        }
        unbinder = ButterKnife.bind(this, mContextView);
        initView(mContextView);

        registerEvent();
        isResiterEvent = true;

        return mContextView;


    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        //列表类型的fragment,不要Override doBisiness（），需要Override onActivityCreated（）,在这里面加入新的判断再自定义一个加载数据的方法
        doBusiness(getActivity());
        mPresent.fetch();

    }

    /**
     * [绑定布局]
     *
     * @return
     */
    public abstract int bindLayout();

    /**
     * [初始化控件]
     *
     * @param view
     */
    public abstract void initView(final View view);

    /**
     * [业务操作]
     *
     * @param mContext
     */
    public abstract void doBusiness(Context mContext);

    /**
     * View点击
     **/
    public abstract void widgetClick(View v);

    @Override
    public void onClick(View v) {
        widgetClick(v);
    }

    /*
     * @params
     * @name 子类实现具体的构建过程
     * @data 2017/11/20 15:39
     * @author :MarkShuai
     */
    protected abstract T createPresent();

    @Override
    public void onDestroy() {
        //解绑(防止内存泄漏)
        mPresent.detach();
        unbinder.unbind();
        super.onDestroy();
    }


    /// 懒加载模块


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        isViewCreated = true;
        lazyLoadAct();
        if (!isResiterEvent) {
            registerEvent();
        }
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        //isVisibleToUser这个boolean值表示:该Fragment的UI 用户是否可见
        if (isVisibleToUser) {
            isUIVisible = true;
            lazyLoadAct();
        } else {
            isUIVisible = false;
        }

    }

    private void lazyLoadAct() {
        //这里进行双重标记判断,是因为setUserVisibleHint会多次回调,并且会在onCreateView执行前回调,必须确保onCreateView加载完毕且页面可见,才加载数据
        if (isViewCreated && isUIVisible) {
            lazyLoad();
            //数据加载完毕,恢复标记,防止重复加载
            if (!isVisibleLoad) {
                isViewCreated = false;
            }
            isUIVisible = false;
        }
    }

    /// Fragment 加载数据接口
    protected abstract void lazyLoad();


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        isViewCreated = false;
        isUIVisible = false;
        unRegisterEvent();
    }

    /**
     * 发送到主线程中去执行
     *
     * @param event
     */
    public void postMain(EventCenter event) {
        MyEventBus.getDefault().postMain(event);
    }

    /**
     * 发送到后台线程执行
     *
     * @param event
     */
    public void postBack(EventCenter event) {
        MyEventBus.getDefault().postBack(event);
    }

    /**
     * 如果不想解注册请在子类复写此方法，
     * 但一定要找时机调用父类的unRegisterEvent,否则会造成内存泄露
     */
    public void unRegisterEvent() {
        MyEventBus.getDefault().unregister(this);
    }

    /**
     * 注册eventbus
     */
    public void registerEvent() {
        MyEventBus.getDefault().register(this);
    }

    /**
     * 在当前线程执行
     *
     * @param msg
     */
    @Override
    public boolean onInterceptEvent(EventCenter msg) {
        return false;
    }

    /**
     * 在主线程执行
     *
     * @param msg
     */
    @Override
    public boolean onInterceptEventMainThread(EventCenter msg) {
        return false;
    }

    /**
     * 在后台线程执行
     *
     * @param msg
     */
    @Override
    public boolean onInterceptEventBackgroundThread(EventCenter msg) {
        return false;
    }

    /**
     * 强制新开后台线程执行
     *
     * @param msg
     */
    @Override
    public boolean onInterceptEventAsync(EventCenter msg) {
        return false;
    }


}
