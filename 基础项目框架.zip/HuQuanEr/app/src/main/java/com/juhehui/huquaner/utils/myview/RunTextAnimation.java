package com.juhehui.huquaner.utils.myview;

import android.animation.ValueAnimator;
import android.view.animation.LinearInterpolator;
import android.widget.TextView;

/**
 * 数字累加效果
 */
public class RunTextAnimation {

    public static void intRunAnimation(final TextView textView, int start, int end) {
        ValueAnimator animator = ValueAnimator.ofInt(start, end);
        animator.setDuration(5000);//时长5s
        animator.setInterpolator(new LinearInterpolator());//线性插值器
        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                textView.setText(animation.getAnimatedValue().toString());
            }
        });//监听
        animator.start();
    }

}