package com.juhehui.huquaner.base;

import android.annotation.SuppressLint;
import android.content.Context;
import android.support.multidex.MultiDex;
import android.support.multidex.MultiDexApplication;

import com.juhehui.huquaner.utils.ConfigUtils;
import com.juhehui.huquaner.utils.ConstantManager;
import com.juhehui.huquaner.utils.CustomCrashHandler;
import com.umeng.commonsdk.UMConfigure;
import com.umeng.socialize.PlatformConfig;
import com.umeng.socialize.UMShareAPI;


/**
 * 作者：jun on
 * 时间：2018/3/20 16:55
 * 意图：Application全局的
 */

public class HQApplication extends MultiDexApplication {

    public static HQApplication exampleApplication;
    private static Context context;
    public static UMShareAPI mUMShareAPI;

    //    友盟配置
    {
        PlatformConfig.setWeixin(ConstantManager.WECHATAPPID, ConstantManager.WECHATSECRET);//真的
        PlatformConfig.setQQZone("100424468", "c7394704798a158208a74ab60104f0ba");//假的
        PlatformConfig.setSinaWeibo("3921700954", "04b48b094faeb16683c32669824ebdad", "http://sns.whalecloud.com");//假的
    }
    @SuppressLint("NewApi")
    @Override
    public void onCreate() {
        super.onCreate();
        exampleApplication = this;
        context = getApplicationContext();

        setCrash();
        initToken();
        initUmeng();
    }

    /**
     * 友盟初始化
     */
    private void initUmeng() {
        mUMShareAPI = UMShareAPI.get(this);
        /**
         * 第一个参数是application
         * 第二个是Appkey
         * 第三个是channel（只用share可以不写）
         * 第四个参数是设备类型
         * 第五个参数为push的secret
         */
        UMConfigure.init(this, ConstantManager.UMENGAPPID, "umeng", UMConfigure.DEVICE_TYPE_PHONE, "");
    }



    public static String token;

    private void initToken() {
        token = ConfigUtils.getINSTANCE().getDeviceId(this);
    }





    public static Context getContext() {
        return context;
    }

    public static HQApplication getInstance() {
        return exampleApplication;
    }


    private void setCrash() {
        // 在使用 SDK 各组间之前初始化 context 信息，传入 ApplicationContext
        // 异常捕捉
        try {
            CustomCrashHandler mCustomCrashHandler = CustomCrashHandler.getInstance();
            mCustomCrashHandler.setCustomCrashHanler(getApplicationContext());
        } catch (Exception e) {
            // TODO: handle exception
        }
    }

    /**
     * 分割 Dex 支持
     *
     * @param base
     */
    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        MultiDex.install(this);
    }

}
