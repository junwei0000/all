package com.juhehui.huquaner.utils.widget.jswebview.browse;


/**
 * @param
 * @author MarkShuai
 * @name
 */
public interface CallBackFunction {

    void onCallBack(String data);

}
