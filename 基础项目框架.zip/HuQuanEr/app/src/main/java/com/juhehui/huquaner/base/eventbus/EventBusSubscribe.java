package com.juhehui.huquaner.base.eventbus;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

/**
 * Created by liuchao on 2018.5.28.
 */
public class EventBusSubscribe {
    private ArrayList<IEventBusListener> mList = new ArrayList<>();
    private LinkedHashMap<String, IEventBusListener> mSubscirbers = new LinkedHashMap();

    public synchronized void register(Object subscriber) {
        if (subscriber instanceof IEventBusListener) {
            if (!mList.contains(subscriber)) {
                mList.add((IEventBusListener) subscriber);
            }
//            mSubscirbers.put(subscriber.getClass().getName(),(IEventBusListener) subscriber);

        }
    }

    public synchronized boolean isRegistered(Object subscriber) {
        return mList.contains(subscriber);
//        return mSubscirbers.containsKey(subscriber.getClass().getName());
    }

    public synchronized void unregister(Object subscriber) {
        Object obj = mList.remove(subscriber);
//        Object obj = mSubscirbers.remove(subscriber.getClass().getName());
    }

    public synchronized boolean isEmpty() {
        return mList.isEmpty();
//        return mSubscirbers.isEmpty();
    }

    private synchronized List<IEventBusListener> cloneList() {
        return (List<IEventBusListener>) mList.clone();
//        List<IEventBusListener> list = new ArrayList<>();
//        Collection<IEventBusListener> iterator = mSubscirbers.values();
//        for(IEventBusListener i:iterator) {
//            list.add(i);
//        }
//        return  list;
    }

    @Subscribe(threadMode = ThreadMode.BACKGROUND) //第2步:注册一个在后台线程执行的方法,用于接收事件
    public void onEventBackground(BackEvent event) {

        List<IEventBusListener> list = cloneList();
        IEventBusListener listener;
        boolean isIntercept = false;
        for (int i = list.size() - 1; i >= 0; i--) {
            listener = list.get(i);
            isIntercept = listener.onInterceptEventBackgroundThread(event.event);
            if (isIntercept) {
                break;
            }
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventMain(MainEvent event) {

        List<IEventBusListener> list = cloneList();
        IEventBusListener listener;
        boolean isIntercept = false;
        for (int i = list.size() - 1; i >= 0; i--) {
            listener = list.get(i);
            isIntercept = listener.onInterceptEventMainThread(event.event);
            if (isIntercept) {
                break;
            }
        }
    }

    @Subscribe(threadMode = ThreadMode.ASYNC)
    public void onEeventAsync(AsyncEvent event) {

        List<IEventBusListener> list = cloneList();
        IEventBusListener listener;
        boolean isIntercept = false;
        for (int i = list.size() - 1; i >= 0; i--) {
            listener = list.get(i);
            isIntercept = listener.onInterceptEventAsync(event.event);
            if (isIntercept) {
                break;
            }
        }
    }

    @Subscribe(threadMode = ThreadMode.POSTING)
    public void onEeventCurrent(CurrentEvent event) {

        List<IEventBusListener> list = cloneList();
        IEventBusListener listener;
        boolean isIntercept = false;
        for (int i = list.size() - 1; i >= 0; i--) {
            listener = list.get(i);
            isIntercept = listener.onInterceptEvent(event.event);
            if (isIntercept) {
                break;
            }
        }
    }
}
