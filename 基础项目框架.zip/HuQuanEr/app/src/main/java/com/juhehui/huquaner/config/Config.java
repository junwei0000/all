package com.juhehui.huquaner.config;

/**
 * Created by caodebo on 2017/4/19.
 */

public class Config {

    /**
     * 网络请求超时时间毫秒
     */
    public static final long DEFAULT_TIMEOUT = 20000;
    /**
     * 基础URL
     */
    public static final String VERSION = "v1_8_0/";
    /**
     * **********正式地址***************
     */

    public static final String BASE_URL = "https://t.asdyf.com/api/";
    public static final String WEB_DOMAIN = ";domain=t.asdyf.com;path=/";
    public static final String BASE_HEAD_URL = "https://t.asdyf.com/";

    /**
     * **********测试地址***************
     */

//    public static final String BASE_URL = "http://test.t.asdyf.com/api/";
//    public static final String WEB_DOMAIN = ";domain=test.t.asdyf.com;path=/";
//    public static final String BASE_HEAD_URL = "http://test.t.asdyf.com/";

}
