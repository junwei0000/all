package com.juhehui.huquaner.utils.widget.jswebview.browse.JsWeb;

/**
 * @param
 * @author MarkShuai
 * @name 回调
 */
public interface JavaCallHandler {

    public void OnHandler(String handlerName, String jsResponseData);
}
