package com.juhehui.huquaner.modular.webView;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;
import android.webkit.GeolocationPermissions;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.juhehui.huquaner.R;
import com.juhehui.huquaner.base.BaseActivity;
import com.juhehui.huquaner.config.Config;
import com.juhehui.huquaner.utils.AblumWebUtils;
import com.juhehui.huquaner.utils.ConfigUtils;
import com.juhehui.huquaner.utils.CustomCrashHandler;
import com.juhehui.huquaner.utils.sharedpreferenceutils.UserUtils;
import com.juhehui.huquaner.utils.widget.dialog.LoadingDialogAnim;
import com.juhehui.huquaner.utils.widget.jswebview.browse.BridgeHandler;
import com.juhehui.huquaner.utils.widget.jswebview.browse.BridgeWebView;
import com.juhehui.huquaner.utils.widget.jswebview.browse.BridgeWebViewClient;
import com.juhehui.huquaner.utils.widget.jswebview.browse.CallBackFunction;
import com.umeng.analytics.MobclickAgent;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Map;

import butterknife.BindView;
import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

/**
 * Created by Burning on 2018/9/11.
 */

public abstract class WebAct extends BaseActivity {

    @BindView(R.id.pageTop_tv_name)
    public TextView pageTopTvName;
    @BindView(R.id.webView)
    public BridgeWebView mBridgeWebView;

    @BindView(R.id.layout_notdate)
    LinearLayout llNodata;
    @BindView(R.id.not_date_img)
    ImageView ivNodata;
    @BindView(R.id.not_date_cont)
    TextView tvNoDataContent;
    @BindView(R.id.not_date_cont_title)
    TextView tvNoDataTitle;
    @BindView(R.id.not_date_btn)
    TextView btnNoData;


    private ValueCallback<Uri> mUploadMessage;
    private ValueCallback<Uri[]> mUploadCallbackAboveL;

    public int wbGoBack = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View bindView() {
        return null;
    }

    @Override
    public int bindLayout() {
        return R.layout.activity_web;
    }

    @Override
    public void initDataAfter() {

    }

    @Override
    public void setListener() {
    }

    @Override
    public void onClick(View view) {

    }

    String baseurl;

    public void loadUrl(String url) {
        this.baseurl = url;
        if (!TextUtils.isEmpty(baseurl)) {
            mBridgeWebView.addUrlPageBackListItem(baseurl);
            sewtCookie(baseurl);
        }
        // 打开页面，也可以支持网络url
        mBridgeWebView.loadUrl(baseurl);
    }

    /**
     * 缓存  Cookie
     */
    private void sewtCookie(String url) {
        //设置网络请求cookie
        CookieSyncManager.createInstance(this);
        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
//        cookieManager.removeAllCookie();//移除
        String name = UserUtils.getUserName(mContext);
        String phone = UserUtils.getUserPhone(mContext);
        String userId = UserUtils.getUserId(mContext);
        String avatar = UserUtils.getUserAvatar(mContext);
        String token = UserUtils.getWXToken(mContext);
        int vercode = ConfigUtils.getINSTANCE().getVersionCode(mContext);
        //Config.WEB_DOMAIN域名
        cookieManager.setCookie(url, "phone_user_name=" + name + Config.WEB_DOMAIN);
        cookieManager.setCookie(url, "phone_user_phone=" + phone + Config.WEB_DOMAIN);
        cookieManager.setCookie(url, "phone_user_id=" + userId + Config.WEB_DOMAIN);
        cookieManager.setCookie(url, "phone_user_avatar=" + avatar + Config.WEB_DOMAIN);
        cookieManager.setCookie(url, "phone_user_token=" + token + Config.WEB_DOMAIN);
        cookieManager.setCookie(url, "isApp_Storage=1" + Config.WEB_DOMAIN);
        cookieManager.setCookie(url, "APP_type_pay_source=2" + Config.WEB_DOMAIN);//安卓source=2
        cookieManager.setCookie(url, "versionCode=" + vercode + Config.WEB_DOMAIN);
        Log.e("aaa", "getCookie : " + cookieManager.getCookie(url));
        cookieManager.getCookie(url);
        if (Build.VERSION.SDK_INT < 21) {
            CookieSyncManager.getInstance().sync();
        } else {
            CookieManager.getInstance().flush();
        }
    }

    @Override
    public void initView(View view) {
        initWebView();
    }

    private void initWebView() {
        updateWebPic();
        //刷新头部标题
        mBridgeWebView.registerHandler("public_TitleChange", new BridgeHandler() {
            @Override
            public void handler(String data, CallBackFunction function) {
                Log.e("registerHandler", "data=" + data);
                if (pageTopTvName != null)
                    pageTopTvName.setText("" + data);
            }
        });
    }
    boolean showErr = false;

    private void showNoDataView(boolean flag) {
        if (mBridgeWebView == null) {
            return;
        }
        Log.e("showChache", "showNoDataView=" + flag);
        int showNodata = flag ? View.VISIBLE : View.GONE;
        int showData = flag ? View.GONE : View.VISIBLE;
        mBridgeWebView.setVisibility(showData);
        llNodata.setVisibility(showNodata);
        tvNoDataContent.setVisibility(showNodata);
        tvNoDataTitle.setVisibility(showNodata);
        btnNoData.setVisibility(showNodata);
        ivNodata.setVisibility(showNodata);
        ivNodata.setBackgroundResource(R.mipmap.my_network_icon);
        tvNoDataContent.setText("请刷新或检查网络");
        tvNoDataTitle.setText("网络加载失败");
        btnNoData.setText("刷新");
        btnNoData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showErr = false;
                mBridgeWebView.reload();
            }
        });
    }

    /**
     * ***********************上传图片*************************
     */
    private void updateWebPic() {
        //开启长按复制粘贴
        mBridgeWebView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                //如果想要屏蔽只需要返回ture 即可
                return false;
            }
        });
        mBridgeWebView.setWebChromeClient(new WebChromeClient() {
            // 配置权限（同样在WebChromeClient中实现）
            @Override
            public void onGeolocationPermissionsShowPrompt(String origin,
                                                           GeolocationPermissions.Callback callback) {
                callback.invoke(origin, true, false);
                super.onGeolocationPermissionsShowPrompt(origin, callback);
            }


            // For Android 5.0+
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                mUploadCallbackAboveL = filePathCallback;
                choseSinglePic();
                return true;
            }
            // For Android 3.0+

            public void openFileChooser(ValueCallback<Uri> uploadMsg) {
                mUploadMessage = uploadMsg;
                choseSinglePic();
            }
            //3.0--版本

            public void openFileChooser(ValueCallback<Uri> uploadMsg, String acceptType) {
                mUploadMessage = uploadMsg;
                choseSinglePic();
            }
            // For Android 4.1

            public void openFileChooser(ValueCallback<Uri> uploadMsg, String acceptType, String capture) {
                mUploadMessage = uploadMsg;
                choseSinglePic();
            }
        });
        mBridgeWebView.setWebViewClient(new BridgeWebViewClient(mBridgeWebView) {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                mHandler.sendEmptyMessage(SHOWDIALOG);
                Log.e("URLDecoder", "onPageStarted  =" + url);
                super.onPageStarted(view, url, favicon);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                setLoadPicEnd(view);
                super.onPageFinished(view, url);
                Log.e("URLDecoder", "onPageFinished url=" + url);
                mHandler.sendEmptyMessage(DISMISSDIALOG);
            }

            //Android6.0以上404或者500处理
            @TargetApi(Build.VERSION_CODES.M)
            @Override
            public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse errorResponse) {
                super.onReceivedHttpError(view, request, errorResponse);
                int statusCode = errorResponse.getStatusCode();
                //404 图片问题
                if (500 == statusCode) {
                    Log.e("URLDecoder", "onReceivedHttpError statusCode=" + statusCode
                            + "  " + errorResponse.getReasonPhrase());
                    CustomCrashHandler.getInstance().savaInfoToSDNew(mContext, "onReceivedHttpError statusCode=" + statusCode
                            + "  " + errorResponse.getReasonPhrase());
                    MobclickAgent.reportError(mContext, "onReceivedHttpError statusCode=" + statusCode
                            + "  " + errorResponse.getReasonPhrase());

                    showErr = true;
                    showNoDataView(showErr);
                }
            }

            //Android6.0以上断网和链接超时处理
            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                Log.e("URLDecoder", "onReceivedError errorCode=" + errorCode);
                showErr = true;
                showNoDataView(showErr);
                super.onReceivedError(view, errorCode, description, failingUrl);
            }
        });
    }

    /**
     * 设置webview图片缓存本地----加载结束设置
     *
     * @param view
     */

    public void setLoadPicEnd(WebView view) {
//        view.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
//        view.getSettings().setBlockNetworkImage(false);
    }

    AblumWebUtils mAblumPicUtils;

    private void choseSinglePic() {
        if (mAblumPicUtils == null) {
            mAblumPicUtils = new AblumWebUtils(mActivity, mUploadMessage, mUploadCallbackAboveL);
        }
        mAblumPicUtils.setmUploadMessage(mUploadMessage);
        mAblumPicUtils.setmUploadCallbackAboveL(mUploadCallbackAboveL);
        mAblumPicUtils.onAddAblumClick();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mAblumPicUtils != null && mAblumPicUtils.selectDialog != null && mAblumPicUtils.selectDialog.isShowing()) {
            mAblumPicUtils.selectDialog.dismiss();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        try {
            if (requestCode == mAblumPicUtils.RESULTCAMERA
                    || requestCode == mAblumPicUtils.RESULTGALLERY) {
                mAblumPicUtils.setResult(requestCode, resultCode, data);
            }
        } catch (Exception e) {
        }
        super.onActivityResult(requestCode, resultCode, data);
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mBridgeWebView != null) {
            mBridgeWebView.urlPageBackList.clear();
            mBridgeWebView.destroy();
        }
    }

    /**
     * 点击返回的时间间隔
     */
    private long clickBackTime = 0;

    /**
     * 防止连续点击返回键
     */
    public void back() {
        if (mBridgeWebView != null && mBridgeWebView.canGoBack() && mBridgeWebView.urlPageBackList.size() > 1) {
            if ((System.currentTimeMillis() - clickBackTime) > 500) {
                clickBackTime = System.currentTimeMillis();
                showDialog();
                //防止同时操作主线程阻塞
                mHandler.sendEmptyMessage(GOBACKPAGE);
            }
        } else {
            doFinish2();
        }
    }

    private static final int GOBACKPAGE = -1;
    private static final int SHOWDIALOG = -2;
    private static final int DISMISSDIALOG = -3;
    @SuppressLint("HandlerLeak")
    Handler mHandler = new Handler() {
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case GOBACKPAGE:
                    //---------------------webview关于返回错乱----修改.1-----------------------------------------------
                    String url = mBridgeWebView.getUrl();
                    int index = -1;
                    if (mBridgeWebView.urlPageBackList.contains(url)) {
                        index = mBridgeWebView.urlPageBackList.indexOf(url);
                    }
                    Log.e("goBack", "urlPageBackList=\n" + mBridgeWebView.urlPageBackList.toString());
                    Log.e("goBack", "goBack------index==" + index + "  beforepageIndex==" + mBridgeWebView.beforepageIndex + " mBridgeWebView.getUrl= " + mBridgeWebView.getUrl());
                    mBridgeWebView.clickPageBacking = true;
                    if (index > 0) {
                        if (index == mBridgeWebView.beforepageIndex) {//相同的页面无法返回时，回到首页
                            mBridgeWebView.loadUrl(baseurl);
                        } else {
                            mBridgeWebView.goBack();
                        }
                    } else {//等于0或-1堆栈错乱 关闭页面
                        doFinish2();
                    }
                    mBridgeWebView.beforepageIndex = index;
                    //------------------------------------------------------------------------
                    break;
                case SHOWDIALOG:
                    showDialog();
                    break;
                case DISMISSDIALOG:
                    dismissDialog();
                    if (!showErr) {
                        showNoDataView(false);
                    }
                    break;
            }
        }
    };

    public void showDialog() {
        RequestDataStatus = true;
        LoadingDialogAnim.show(mContext);
    }

    public void dismissDialog() {
        RequestDataStatus = false;
        LoadingDialogAnim.dismiss(mContext);
    }
}
