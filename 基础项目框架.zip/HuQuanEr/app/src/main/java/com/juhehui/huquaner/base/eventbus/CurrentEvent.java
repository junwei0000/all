package com.juhehui.huquaner.base.eventbus;

/**
 * Created by liuchao on 2018.5.28.
 */
public class CurrentEvent extends IEvent {
    CurrentEvent(EventCenter event) {
        this.event = event;
    }
}
