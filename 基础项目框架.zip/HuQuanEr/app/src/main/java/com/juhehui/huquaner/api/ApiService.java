package com.juhehui.huquaner.api;


import com.juhehui.huquaner.bean.login.LoginDataBean;
import com.juhehui.huquaner.bean.version.VersionDataBean;
import com.juhehui.huquaner.config.Config;

import io.reactivex.Observable;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

/**
 * get请求：在方法上使用@Get注解来标志该方法为get请求，在方法中的参数需要用@Query来注释。
 * Post请求：使用@FormUrlEncoded和@POST注解来发送表单数据。
 * 使用 @Field注解和参数来指定每个表单项的Key，value为参数的值。
 * 需要注意的是必须要使用@FormUrlEncoded来注解，因为post是以表单方式来请求的。
 */
public interface ApiService {
    @GET("version/android")
    Observable<VersionDataBean> updateVersion(@Query("version") String version);

    //********************用户登录，个人信息***************************
    @FormUrlEncoded
    @POST(Config.VERSION + "login/account")
    Observable<LoginDataBean> userAccountLogin(@Field("phone") String phone,
                                               @Field("password") String password,
                                               @Field("login_ip") String login_ip,
                                               @Field("lat") double phone_user_latitude,
                                               @Field("lon") double phone_user_longitude,
                                               @Field("login_address") String phone_user_address,
                                               @Field("token") String token);
}


