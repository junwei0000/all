package com.juhehui.huquaner.base;

/**
 * Created by msi on 2018-12-24.
 */

public class EventCode {
    //订单的城市选择结束
    public static final int UPDATA_GROUPORDER_ZFS = 1001; // 刷新祝福师大厅小红点数据

    public static final int UPDATA_GROUPORDER_CAIWU_ORDER = 1002;// JinTie 财务提现订单列表

    public static final int UPDATA_USER_ORDER_PRICE_CAIWU_ORDER = 1003;//订单详情finish
    public static final int SEARCH_ORDER_BACK = 1004;
    public static final int MAP_STOP = 1005;
    public static final int MAP_USER_RESH = 1006;//刷新数据
    public static final int FRIEND_USER_RESH = 1007;//刷新数据
    public static final int WEB_RESH = 1008;//刷新数据
    public static final int LOGOUT_USER = 1009;//刷新数据

    public static final int BACK_HOME_USER = 1010;//刷新数据
    public static final int BACK_FANGZU_LIST_ZFS_USER = 1011;//刷新数据

    public static final int BACK_TIME_USER = 1012;//倒计时

    public static final int BACK_GROUP_LIST_USER_0 = 1013;
    public static final int BACK_GROUP_LIST_USER_1 = 1014;
    public static final int BACK_GROUP_LIST_USER_ITEM = 1015;
    public static final int UPDATA_GROUPORDER_ZFS_FZ = 1016; //

    public static final int SHUIKU_FRAGMENT_DATE_UPDATE = 10018;//刷新数据
//    public static final int YEARS_GOODS_ORDER_BACK = 1017;

}
