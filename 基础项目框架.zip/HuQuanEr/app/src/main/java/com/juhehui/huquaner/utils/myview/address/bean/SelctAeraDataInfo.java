package com.juhehui.huquaner.utils.myview.address.bean;


import com.juhehui.huquaner.bean.ResponseBean;

import java.util.ArrayList;

public class SelctAeraDataInfo extends ResponseBean {
    private ArrayList<SelctAeraInfo> data;

    public ArrayList<SelctAeraInfo> getData() {
        return data;
    }

    public void setData(ArrayList<SelctAeraInfo> data) {
        this.data = data;
    }


}
