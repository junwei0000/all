package com.juhehui.huquaner.modular.index.welcome.bean;

/**
 * 作者：MarkShuai
 * 时间：2017/12/8 16:37
 * 邮箱：MarkShuai@163.com
 * 意图：
 */

public class WelcomeBean {
    private int drawableID;

    public int getDrawableID() {
        return drawableID;
    }

    public void setDrawableID(int drawableID) {
        this.drawableID = drawableID;
    }


}
