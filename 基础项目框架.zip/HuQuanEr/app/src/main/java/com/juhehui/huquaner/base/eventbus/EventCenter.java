package com.juhehui.huquaner.base.eventbus;

/**
 * Created by liuchao on 2018.5.28.
 */
public class EventCenter {
    /**
     * reserved data
     */
    private Object data;

    /**
     * this code distinguish between different events
     */
    private int eventCode = -1;

    public EventCenter(int eventCode) {
        this(eventCode, null);
    }

    public EventCenter(int eventCode, Object data) {
        this.eventCode = eventCode;
        this.data = data;
    }

    /**
     * get event code
     *
     * @return
     */
    public int getEventCode() {
        return this.eventCode;
    }

    /**
     * get event reserved data
     *
     * @return
     */
    public Object getData() {
        return this.data;
    }


}