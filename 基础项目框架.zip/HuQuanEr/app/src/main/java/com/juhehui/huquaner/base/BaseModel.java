package com.juhehui.huquaner.base;

/**
 * 作者：MarkShuai
 * 时间：2017/11/22 14:11
 * 邮箱：MarkShuai@163.com
 * 意图：Model的Base类
 */

public interface BaseModel {
}
