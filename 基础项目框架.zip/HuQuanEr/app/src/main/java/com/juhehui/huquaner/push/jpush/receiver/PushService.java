package com.juhehui.huquaner.push.jpush.receiver;


import cn.jpush.android.service.JCommonService;

public class PushService extends JCommonService {

}
