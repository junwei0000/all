package com.juhehui.huquaner.utils.widget.jswebview.browse.JsWeb;


import com.juhehui.huquaner.utils.widget.jswebview.browse.CallBackFunction;

/**
 * @param
 * @author MarkShuai
 * @name
 */
public interface JsHandler {

    public void OnHandler(String handlerName, String responseData, CallBackFunction function);

}
