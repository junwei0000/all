package com.juhehui.huquaner.wxapi;



import com.umeng.socialize.weixin.view.WXCallbackActivity;

/**
 * 意图：分享 WXCallbackActivity
 */

public class WXEntryActivity extends WXCallbackActivity {

}
