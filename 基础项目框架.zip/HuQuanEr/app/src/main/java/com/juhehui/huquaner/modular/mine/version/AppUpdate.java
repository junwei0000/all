package com.juhehui.huquaner.modular.mine.version;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;
import android.content.DialogInterface.OnKeyListener;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.Display;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;


import com.juhehui.huquaner.R;
import com.juhehui.huquaner.api.Api;
import com.juhehui.huquaner.base.ActivityManager;
import com.juhehui.huquaner.base.HQApplication;
import com.juhehui.huquaner.bean.version.VersionAfterBean;
import com.juhehui.huquaner.bean.version.VersionDataBean;
import com.juhehui.huquaner.push.jpush.broadcast.LocalBroadcastManager;
import com.juhehui.huquaner.utils.ConfigUtils;
import com.juhehui.huquaner.utils.ConstantManager;
import com.juhehui.huquaner.utils.ToastUtils;
import com.juhehui.huquaner.utils.myview.MyDialog;

import java.util.ArrayList;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

/**
 * app更新
 */
public class AppUpdate {
    private Activity context;
    private MyDialog selectDialog;
    /**
     * 是否已经显示更新弹层
     */
    private boolean dialogstatus = false;

    /**
     * 数据正在加载中
     */
    private boolean loadDataStatus = false;


    /**
     * 方法说明：启动异步任务
     *
     * @param updateDirection
     */
    public void startUpdateAsy(Activity context, String updateDirection) {
        this.context = context;
        String verName =  ConfigUtils.getINSTANCE().getVersionName(context);
        if (!TextUtils.isEmpty(verName) && !loadDataStatus && !dialogstatus) {
            loadDataStatus = true;
            getServerVerCode(verName, updateDirection);
        }
    }

    String level = "0";

    /**
     * 方法说明：与服务器交互获取当前程序版本号
     *
     * @param appVersion
     * @param updateDirection 请求路径
     * @return
     */
    private String getServerVerCode(String appVersion, final String updateDirection) {
        if (!TextUtils.isEmpty(appVersion) && appVersion.contains(".")) {
            Log.e("appVersion", "appVersion=" + appVersion);
            appVersion = appVersion.replace(".", "_");
        }
        Log.e("showUpdaDialog", "appVersion new=" + appVersion);
        Observable<VersionDataBean> observable = Api.getInstance().service.updateVersion(appVersion);
        observable.subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new io.reactivex.functions.Consumer<VersionDataBean>() {
                    @Override
                    public void accept(VersionDataBean responseBean) throws Exception {
                        String status = responseBean.getStatus();
                        loadDataStatus = false;
                        if (status.equals("200")) {
                            VersionAfterBean mVersionAfterBean = responseBean.getData();
                            if (mVersionAfterBean != null) {
                                String url = mVersionAfterBean.getUrl();
                                String version = mVersionAfterBean.getVersion();
                                level = mVersionAfterBean.getLevel();
                                Log.e("showUpdaDialog", "level=" + level);
                                if (level.equals("0")) {
                                    if (TextUtils.isEmpty(updateDirection)) {
                                         ToastUtils.showToast("当前已为最新版本");
                                    }
                                } else {// 更新
                                    dialogstatus = true;
                                    Intent intents = new Intent();
                                    intents.setAction(ConstantManager.MAINMENU_ACTION);
                                    intents.putExtra("type", ConstantManager.MAIN_ACTION_UpdateVerDisAllDialog);
                                    LocalBroadcastManager.getInstance(HQApplication.getContext()).sendBroadcast(intents);

                                    ArrayList<String> descriptionList = mVersionAfterBean.getDescription();
                                    StringBuffer description = new StringBuffer();
                                    if (descriptionList != null && descriptionList.size() > 0) {
                                        for (String str : descriptionList) {
                                            description.append(str + "\n");
                                        }
                                    }
                                    defineUpdated(version, url, level, description.toString());
                                }
                            }
                        }
                    }
                }, new io.reactivex.functions.Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        Log.e("Observable", "" + throwable.toString());
                        loadDataStatus = false;
                    }
                });
        return null;
    }


    /**
     * 方法说明：更新对话框提示 后台更新
     *
     * @param androidVersion
     * @param url
     * @param level          0：不用更新 1：必须更新 2：非必须更新
     * @param description
     */
    public void defineUpdated(String androidVersion, final String url, final String level, String description) {
        selectDialog = new  MyDialog(context, R.style.dialog, R.layout.dialog_updateversion);// 创建Dialog并设置样式主题
        selectDialog.setCanceledOnTouchOutside(false);// 设置点击Dialog外部任意区域关闭Dialog
        selectDialog.show();
        WindowManager m = context.getWindowManager();
        Display d = m.getDefaultDisplay(); //为获取屏幕宽、高
        WindowManager.LayoutParams p = selectDialog.getWindow().getAttributes(); //获取对话框当前的参数值
        p.width = d.getWidth() * 3 / 4; //宽度设置为屏幕
        selectDialog.getWindow().setAttributes(p); //设置生效
        selectDialog.setOnDismissListener(new OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface arg0) {
                dialogstatus = false;
            }
        });
        selectDialog.setOnKeyListener(new OnKeyListener() {
            public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
                // 必须更新
                return level.equals("1") && selectDialog.isShowing();
            }
        });
        ImageView iv_top = selectDialog.findViewById(R.id.iv_top);
        iv_top.setLayoutParams(new LinearLayout.LayoutParams(d.getWidth() * 3 / 4, (int) (p.width * 0.64)));
        TextView tv_version = selectDialog.findViewById(R.id.tv_version);
        TextView tv_cont = selectDialog.findViewById(R.id.tv_cont);
        TextView tv_update = selectDialog.findViewById(R.id.tv_update);
        TextView tv_xicai = selectDialog.findViewById(R.id.tv_xicai);
        if (!TextUtils.isEmpty(androidVersion) && androidVersion.contains("_")) {
            androidVersion = androidVersion.replace("_", ".");
        }
        tv_version.setText("版本号：V" + androidVersion);
        tv_cont.setText(description);
        tv_update.setOnClickListener(new OnClickListener() {
            public void onClick(View arg0) {
                if (Build.VERSION.SDK_INT >= 23) {
                    if (!Settings.canDrawOverlays(context)) {
                        //没有悬浮窗权限m,去开启悬浮窗权限
                        try {
                            Uri packageURI = Uri.parse("package:" + context.getPackageName());
                            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, packageURI);
                            context.startActivityForResult(intent, 11);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
                Intent updateIntent = new Intent(context, UpdateService.class);
                updateIntent.putExtra("url", url);
                context.startService(updateIntent);
                if (level.equals("1")) {
                    // 必须更新
                } else {
                    selectDialog.dismiss();
                }
            }
        });
        tv_xicai.setOnClickListener(new OnClickListener() {
            public void onClick(View arg0) {
                if (level.equals("1")) {
                    // 必须更新时点击取消退出程序
                    ActivityManager.getScreenManager().backHome(context);
                } else {
                    selectDialog.dismiss();
                }
            }
        });

    }
}
