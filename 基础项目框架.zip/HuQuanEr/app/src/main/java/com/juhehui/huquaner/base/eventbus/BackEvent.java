package com.juhehui.huquaner.base.eventbus;

/**
 * Created by liuchao on 2018.5.28.
 */
public class BackEvent extends IEvent {
    BackEvent(EventCenter event) {
        this.event = event;
    }
}
